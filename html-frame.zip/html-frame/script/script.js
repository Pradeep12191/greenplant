$(document).ready(() => {
$('.banner-slider').addClass('banner-slider-animate')
$('.content-color').addClass('content-color-animate')
})